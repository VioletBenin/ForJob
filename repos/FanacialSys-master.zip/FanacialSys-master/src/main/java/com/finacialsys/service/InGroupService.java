package com.finacialsys.service;

public interface InGroupService {

}
