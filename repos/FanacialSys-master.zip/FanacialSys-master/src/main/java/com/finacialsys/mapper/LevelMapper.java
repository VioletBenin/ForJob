package com.finacialsys.mapper;

import com.finacialsys.model.entity.Level;

public interface LevelMapper {
	Level getLevel(String userID);
}
