package com.finacialsys.model.entity;

public class ImcomeGroup {

}
