$("#incomeShow").click(function(){
	location.href = "incomeShow";
});

$("#expandShow").click(function(){
	location.href = "expandShow";
});

$("#expandGroupShow").click(function(){
	location.href = "expandGroupShow";
});

$("#incomeGroupShow").click(function(){
	location.href = "incomeGroupShow";
});

