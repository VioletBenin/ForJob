package shop;

public class Shop {
	public static void main(String[] args) {
		new MainWin();
	}
}
