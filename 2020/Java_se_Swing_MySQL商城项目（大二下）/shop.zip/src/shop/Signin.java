package shop;

import javax.swing.JDialog;

public class Signin extends JDialog {
	Signin() {
		
	}
	boolean getSignin(String usr,String psd)
	{		
//		if()
//		return true;
		
		return false;
	}
}
