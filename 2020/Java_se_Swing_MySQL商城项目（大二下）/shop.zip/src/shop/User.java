package shop;

public class User {

}
