package shop;

public class Goods {

}
