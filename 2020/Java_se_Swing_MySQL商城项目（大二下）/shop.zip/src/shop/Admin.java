package shop;

public class Admin {
	Goods bought;
}
